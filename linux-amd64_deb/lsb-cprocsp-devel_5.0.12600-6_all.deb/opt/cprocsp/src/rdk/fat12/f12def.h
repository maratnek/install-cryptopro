#ifndef F12DEF_INCLUDED
#define F12DEF_INCLUDED
#include "reader.kit/sup_sys.h"
#ifdef __cplusplus
extern "C"{
#endif //__cplusplus

DWORD fat12_default_unregister(TSupSysContext* context, TSupSysInfo* info);
DWORD fat12_default_register(TSupSysContext* context, TSupSysInfo* info);
DWORD fat12_default_lock( TSupSysContext *context, TSupSysInfo *info );
DWORD fat12_default_unlock( TSupSysContext *context, TSupSysInfo *info );
DWORD fat12_default_unique_get( TSupSysContext *context, TSupSysInfo *info );
DWORD fat12_default_connect_carrier(TSupSysContext* context, TSupSysInfo* info);
DWORD fat12_default_disconnect_carrier(TSupSysContext* context, TSupSysInfo* info);
DWORD fat12_group_register(TSupSysContext* context, TSupSysInfo* info);
DWORD fat12_group_unregister(TSupSysContext* context, TSupSysInfo* info);
DWORD fat12_group_context_dup(TSupSysContext* context, TSupSysInfo* info);
DWORD fat12_group_context_free(TSupSysContext* context, TSupSysInfo* info);

//internal
DWORD convert_path_to_device_nickname_path(TSupSysInfoText* in_path, TCHAR** out_path_to_item);
DWORD remove_character_from_string(const TCHAR* source, TCHAR sym_to_remove, TCHAR* out_string, size_t* buf_len);
void convert_buffer(TCHAR* buffer, size_t buffer_len);
DWORD ensure_correct_path(TCHAR* buf, size_t buf_len);
DWORD islongnames_by_item_path(const TCHAR* path_to_item, BOOL* long_names);

#ifdef __cplusplus
}
#endif //__cplusplus
#endif //F12DEF_INCLUDED
